# Music Bot Example

  **A Music Discord Bot example written in javascript using discord.js**
  
  Made with ♥ by Client Developer staff: 
  - Staff #1 -> [rayhantech](https://github.com/rayhantech)
  - Staff #2 -> [rnggadosen._](https://github.com/RanggaGultom)
  - Staff #6 -> [Mednoob](https://github.com/Mednoob)
  
  Contributors:
  - @everyone for supporting Client Developer
  - [@KagChi](https://github.com/KagChi/)
  - [@hansputera](https://github.com/hansputera/)
  
# Setup
  1. Clone this repository
  2. Put bot token and youtube API key in `.env`
  3. Put bot prefix and bot owner id in `config.json`
  4. Type this in the console: `$ npm i`
  5. Then, turn the bot on by typing this in the console: `$ npm start`
  
  [Youtube Video](https://youtu.be/rigmqMtWfzM)
  
# Contact Us
 [Discord](https://clientdev.glitch.me/discord)
 
 [Whatsapp](https://chat.whatsapp.com/FRbJk3AIMwL2pKe95IrBwX)
 
# Support Us
[Saweria](https://clientdev.glitch.me/donate/saweria)

[Trakteer](https://clientdev.glitch.me/donate/trakteer)
